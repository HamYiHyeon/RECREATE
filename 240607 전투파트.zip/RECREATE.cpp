﻿#include <iostream>
#include <vector>
#include <string>


#include "CharClass.h"
#include "Enemy.h"
#include "Entity.h"
#include "Skill.h"
#include "Fight.h"
#include "Buff.h"

using namespace std;


int main()
{

    // 적, 플레이어 벡터 생성
    // 적은 동적 할당을 위해 new로 생성
    Thief* thief1 = new Thief;
    thief1->init_skill();
    
    Thief* thief2 = new Thief;
    thief2->init_skill();

    vector<Entity*> enemy;
    enemy.push_back(thief1);
    enemy.push_back(thief2);

    Dealer dealer; 
    dealer.init_skill();
    Healer healer;
    healer.init_skill();
    Tanker tanker;
    tanker.init_skill();
    vector<Entity*> player;
    player.push_back(&dealer);
    player.push_back(&tanker);

    vector<Skill*> chosen_skill;

    vector<Skill*> chosen_skill_enemy;


    // 스킬 사용 - 전투가 끝났는지 확인 - 필요한 요소들 초기화 - 스킬 선정 - 버프 턴 깎기
    // 스킬 사용이 앞에 온 이유는 버프 적용을 용이하게 하기 위하여
    // 플레이어 입장에서는 스킬 사용이 턴 마지막에 오는 것처럼 보임
    while (true) {

        use_skill(chosen_skill, chosen_skill_enemy, &player, &enemy);

        if (enemy.size() == 0 || player.size() == 0)
            break;

        for (int i = 0; i < player.size(); i++)
            player[i]->init_act();
        
        chosen_skill.clear();
        chosen_skill = choose_skill(player, enemy);
        show_skill_fight(chosen_skill);

        chosen_skill_enemy.clear();
        chosen_skill_enemy = choose_skill_enemy(player, enemy);
        show_skill_fight(chosen_skill_enemy);

        for (int i = 0; i < player.size(); i++) {
            count_buff(player[i]);
        }

        for (int i = 0; i < enemy.size(); i++) {
            count_buff(enemy[i]);
        }
    }


}
