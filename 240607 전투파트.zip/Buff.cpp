#include "Entity.h"
#include "Skill.h"

void count_buff(Entity* owner) {

	for (int i = 0; i < owner->buff.size(); i++) {
		
		owner->buff[i]->dec_turn();
		
		if (owner->buff[i]->get_turn() <= 0) {
			
			Buff* del = owner->buff[i];

			owner->change_dmr(del->get_dmg_rate() * (-1));
			owner->change_dfr(del->get_dfs_rate() * (-1));
			
			owner->buff.erase(owner->buff.begin() + i);

			delete del;

			i--;

		}
	}
}