#pragma once
#include <iostream>
#include "Entity.h"
#include "Skill.h"

class Thief : public Entity {

public:
	Thief() { name = "����"; hp = 50; max_hp = 50; }
	virtual void init_skill();
};


class Toad : public Entity {

public:
	Toad() { name = "���β���"; hp = 80; max_hp = 80; }
	virtual void init_skill();
};

class Crocodile : public Entity {

public:
	Crocodile() { name = "�Ǿ�"; hp = 110; max_hp = 110; }
	virtual void init_skill();
};

class Grasshopper : public Entity {
	
public:
	Grasshopper() { name = "�޶ѱ� ��"; hp = 150; max_hp = 150; }
	virtual void init_skill();
};

class Snake : public Entity {

public:
	Snake() { name = "��"; hp = 180; max_hp = 180; }
	virtual void init_skill();
};


class Harpy : public Entity {

public:	
	Harpy() { name = "����"; hp = 200; max_hp = 200; }
	virtual void init_skill();
};

class Wolf : public Entity {

public:
	Wolf() { name = "����"; hp = 200; max_hp = 200; }
	virtual void init_skill();
};

class Fanatic : public Entity {

public:
	Fanatic() { name = "���ŵ�"; hp = 230; max_hp = 230; }
	virtual void init_skill();
};

class Angel : public Entity {

public:
	Angel() { name = "õ��"; hp = 150; max_hp = 150; }
	virtual void init_skill();
};

class God : public Entity {

public:
	God() { name = "��"; hp = 300; max_hp = 300; }
	virtual void init_skill();
};

