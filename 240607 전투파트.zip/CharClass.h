#pragma once
#include "Entity.h"

//name, act, dmgRate
class Dealer : public Entity {

public:
	Dealer() {
		name = "����"; hp = 100; dfs = 10;
		max_hp = 100;
	}

	virtual void init_skill();
};



class Healer : public Entity {

public:
	Healer() {
		name = "����"; hp = 70; dfs = 10;
		max_hp = 70;
	}
	virtual void init_skill();
};



class Tanker : public Entity {

public:
	Tanker() {
		name = "��Ŀ"; hp = 150; dfs = 10;
		max_hp = 150;
	}

	virtual void init_skill();
};