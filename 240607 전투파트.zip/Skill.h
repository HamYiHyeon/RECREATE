#pragma once
#include <string>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

class Entity;

using namespace std;

class Skill {

protected:

    Entity* owner;
    Entity* target;
    string name;

    int act; // �Ҹ� �ൿ�� 
    int dmg; // ���� ����� or ����
    int self; // �ڽſ��� ����ϴ� ��ų�̸� 1, �ƴϸ� 0
    int entire; // ��ü Ÿ�� ��ų�̸� 1, �ƴϸ� 0
    int friendly; // �Ʊ� ��� ��ų�̸� 1, �ƴϸ� 0 

public:

    Skill() { 
        owner = NULL; target = NULL;
        name = "(�˼�����)"; act = 0; dmg = 0; 
        self = 0; entire = 0; friendly = 0;
    }

    virtual void effect(Entity* target) = 0;
    virtual void effect_entire(vector<Entity*>* target) = 0;
    virtual void additional_effect(Entity* target) = 0;

    Entity* get_owner() { return owner; }
    Entity* get_target() { return target; }

    string get_name() { return name; }

    int get_act() { return act; }

    int get_self() { return self; }
    int get_entire() { return entire; }
    int get_friendly() { return friendly; }

    void change_target(Entity* target) { this->target = target; }

};

class Skill_deal : public Skill {

public:

    Skill_deal(Entity* owner, string name, int act, int dmg, int self, int entire, int friendly) { 
        this->owner = owner; this->name = name; this->act = act; this->dmg = dmg; 
        this->self = self; this->entire = entire; this->friendly = friendly;
    }

    // ���� Ÿ�� ��ų�� �Լ�
    void effect(Entity* target);
    // ��ü Ÿ�� ��ų�� �Լ�
    void effect_entire(vector<Entity*>* target);
    // ��ų�� �߰� ȿ�� ������ ���� �Լ� (�̿�)
    void additional_effect(Entity* target);
};



class Skill_dfs : public Skill {

public:

    Skill_dfs(Entity* owner, string name, int act, int dmg, int self, int entire, int friendly) {
        this->owner = owner; this->name = name; this->act = act; this->dmg = dmg; 
        this->self = self; this->entire = entire; this->friendly = friendly;
    }

	void effect(Entity* target);
    void effect_entire(vector<Entity*>* target) { return; }
	void additional_effect(Entity* target);
};


class Skill_heal : public Skill {

public:
    Skill_heal(Entity* owner, string name, int act, int dmg, int self, int entire, int friendly) {
        this->owner = owner; this->name = name; this->act = act; this->dmg = dmg; 
        this->self = self; this->entire = entire;this->friendly = friendly;
    }
	void effect(Entity* target);
    void effect_entire(vector<Entity*>* target);
	void additional_effect(Entity* target);
};
