#include "Skill.h"
#include "Entity.h"

using namespace std;


void Skill_deal::effect(Entity* target) {

	int add_dmg = this->dmg * this->get_owner()->get_dmr() / 100;
	int add_dfs = target->get_dfs() * target->get_dfr() / 100;

	int final_dmg = this->dmg + add_dmg;
	int final_dfs = target->get_dfs() + add_dfs;

	int dmg = final_dmg - final_dfs;
	target->change_hp(dmg);



	cout << this->name << " ���" << endl;
	cout << "Ÿ�� : " << target->get_name() << endl;
	cout << "������ : " << final_dmg << " ���� : " << final_dfs << endl;
	cout << "���� ������ : " << dmg << endl;
	cout << endl;

	additional_effect(target);
	
}

void Skill_deal::effect_entire(vector<Entity*>* target) {

	Entity* del = NULL;

	cout << this->name << "���" << endl;

	for (int i = 0; i < (*target).size(); i++) {

		int dmg = this->dmg - (*target)[i]->get_dfs();
		(*target)[i]->change_hp(dmg);
		cout << "Ÿ�� : " << (*target)[i]->get_name() << endl;
		cout << "������ : " << this->dmg << " ���� : " << (*target)[i]->get_dfs() << endl;
		cout << "���� ������ : " << dmg << endl;
		cout << endl;

		if ((*target)[i]->get_hp() <= 0) {
			cout << (*target)[i]->get_name() << "��(��) ���������ϴ�." << endl;
			cout << endl;

			del = (*target)[i];
			(*target).erase(remove((*target).begin(), (*target).end(), (*target)[i]), (*target).end());
			delete del;
			i--;
		}
	}


}

void Skill_dfs::effect(Entity* target) {

	cout << this->name << "���" << endl;
	cout << "Ÿ�� : " << target->get_name() << endl;
	cout << endl;
	//cout << "������ : " << this->dmg << " ���� : " << target->get_dfs() << endl;
	//cout << "���� ������ : " << dmg << endl;
}


void Skill_heal::effect(Entity* target) {

	int dmg = this->dmg * (-1);
	target->change_hp(dmg);

	if (target->get_hp() > target->get_maxhp()) 
		target->change_hp(target->get_hp() - target->get_maxhp());

	cout << this->name << "���" << endl;
	cout << "Ÿ�� : " << target->get_name() << endl;
	cout << "ȸ���� : " << this->dmg << endl;

}

void Skill_heal::effect_entire(vector<Entity*>* target) {

	cout << this->name << "���" << endl;

	for (int i = 0; i < (*target).size(); i++) {

		int dmg = this->dmg * (-1);
		(*target)[i]->change_hp(dmg);
		if ((*target)[i]->get_hp() > (*target)[i]->get_maxhp()) 
			(*target)[i]->change_hp((*target)[i]->get_hp() - (*target)[i]->get_maxhp());

		cout << "Ÿ�� : " << (*target)[i]->get_name() << endl;
		cout << "ȸ���� : " << this->dmg << endl;

	}
}

void Skill_deal::additional_effect(Entity* target) {

	if (this->name == "�⼱ ����") {
		Buff* buff1 = new Buff(3, 15, 0);
		Buff* buff2 = new Buff(3, -10, 0);

		this->get_owner()->change_dmr(buff1->get_dmg_rate());
		this->get_owner()->buff.push_back(buff1);
		target->change_dmr(buff2->get_dmg_rate());
		target->buff.push_back(buff2);
	}

	else if (this->name == "��ȿ") {
		Buff* buff = new Buff(1, -5, 0);
		target->change_dmr(buff->get_dmg_rate());
		target->buff.push_back(buff);
	}

	else if (this->name == "Ż��") {

		Buff* buff = new Buff(3, 0, 7);

		this->get_owner()->change_dfr(buff->get_dfs_rate());
		this->get_owner()->buff.push_back(buff);
		
	}

	else if (this->name == "�Ǿ��� ����") {
		Buff* buff = new Buff(3, 5, 0);

		this->get_owner()->change_dmr(buff->get_dmg_rate());
		this->get_owner()->buff.push_back(buff);
	}

	else if (this->name == "�Ͽ︵") {
		Buff* buff = new Buff(3, -10, -10);
		target->change_dmr(buff->get_dmg_rate());
		target->change_dfr(buff->get_dfs_rate());
		target->buff.push_back(buff);
	}

}



void Skill_dfs::additional_effect(Entity* target) {

} 

void Skill_heal::additional_effect(Entity* target) {
	

};