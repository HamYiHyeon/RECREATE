#include "CharClass.h"


void Dealer::init_skill() {

	Skill_deal* skill1 = new Skill_deal(this, "���", 3, 25, 0, 0, 0);
	Skill_deal* skill2 = new Skill_deal(this, "���� ����", 4, 30, 0, 0, 0);
	Skill_deal* skill3 = new Skill_deal(this, "���� ���", 5, 25, 0, 1, 0);
	Skill_deal* skill4 = new Skill_deal(this, "�⼱ ����", 5, 10, 0, 0, 0);
	Skill_deal* skill5 = new Skill_deal(this, "���� �˱�", 10, 70, 0, 1, 0);

	ent_skill.push_back(skill1);
	ent_skill.push_back(skill2);
	ent_skill.push_back(skill3);
	ent_skill.push_back(skill4);
	ent_skill.push_back(skill5);


}


void Healer::init_skill() {

	Skill_heal* skill1 = new Skill_heal(this, "ġ��", 2, 15, 0, 0, 1);
	Skill_dfs* skill2 = new Skill_dfs(this, "���", 3, 0, 0, 0, 1);
	Skill_deal* skill3 = new Skill_deal(this, "���� ����", 4, 25, 0, 0, 0);
	Skill_deal* skill4 = new Skill_deal(this, "����", 5, 30, 0, 0, 0);
	Skill_heal* skill5 = new Skill_heal(this, "������ ����", 10, 40, 0, 1, 1);

	ent_skill.push_back(skill1);
	ent_skill.push_back(skill2);
	ent_skill.push_back(skill3);
	ent_skill.push_back(skill4);
	ent_skill.push_back(skill5);

}



void Tanker::init_skill() {

	Skill_deal* skill1 = new Skill_deal(this, "����", 4, 40, 0, 0, 0);
	Skill_deal* skill2 = new Skill_deal(this, "��׷�", 3, 10, 0, 0, 0);
	Skill_dfs* skill3 = new Skill_dfs(this, "����", 3, 0, 1, 0, 0);
	Skill_dfs* skill4 = new Skill_dfs(this, "��� �±�", 3, 0, 0, 0, 1);
	Skill_dfs* skill5 = new Skill_dfs(this, "������ ��ȣ", 10, 0, 0, 1, 1);

	ent_skill.push_back(skill1);
	ent_skill.push_back(skill2);
	ent_skill.push_back(skill3);
	ent_skill.push_back(skill4);
	ent_skill.push_back(skill5);
	
}

