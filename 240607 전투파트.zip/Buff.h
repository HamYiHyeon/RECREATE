#pragma once
#include <iostream>
#include <string>
#include <vector>

class Entity;

class Buff {

private:
	int turn;
	int dmg_rate;
	int dfs_rate;

public:

	Buff(int turn, int dmg_rate, int dfs_rate) { 
		this->turn = turn; 
		this->dmg_rate = dmg_rate; this->dfs_rate = dfs_rate; 
	}
	int get_turn() { return turn; }
	int get_dmg_rate() { return dmg_rate; }
	int get_dfs_rate() { return dfs_rate; }
	void dec_turn() { this->turn = this->turn - 1; }
};

void count_buff(Entity* owner);